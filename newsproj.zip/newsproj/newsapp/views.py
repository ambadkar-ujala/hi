from django.shortcuts import render
# importing api
import requests


def search_kw(request):
    kwdict = " "
    if request.method == 'POST':
        formdata = request.POST
        print(formdata)
        kwdict = formdata.get("kw")
    lst = kwdict.split()
    listToStr = ' '.join(map(str, lst))

    query_params = {
        'q': listToStr, # query phrase
        "sources": "bbc-news",
        "apiKey": "adb1bc05b6e74538bd5953f63ecc12ec"
    }
    main_url = " https://newsapi.org/v2/everything?"


    # fetching data in json format
    res = requests.get(main_url, params=query_params)
    open_bbc_page = res.json()
    article = open_bbc_page["articles"]

    # empty list which will
    # contain all trending news
    results = []

    for ar in article:
        results.append(ar["title"])

    return render(request, 'index.html',{"results":results} )
